#pragma once

#ifdef VITA
// PS Vita: SDL2 provides window/input/audio/threads, vitaGL provides OpenGL (see vita/).
#include "stdafx.h"
#include "vita/vita_gl.h"
namespace SDL {
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "vita/vita_gl_using.inc"
inline void glPixelStorei(GLenum p, GLint v) { vita_glPixelStorei(p, v); }
inline GLenum glGetError() { return vita_glGetError(); }
using ::glDrawBuffers;
using ::glDebugMessageCallback;
using ::glDebugMessageControl;
using ::GLDEBUGPROC;
}
#else
#ifdef WINDOWS
#ifndef _WINDOWS_
#define _WINDOWS_
#define APIENTRY __attribute__((__stdcall__))
#define WINGDIAPI __attribute__((dllimport))
#endif
#else
#define GL_GLEXT_PROTOTYPES 1
#endif

#include "stdafx.h"

namespace SDL {
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_opengl.h>
#include <SDL2/SDL_opengl_glext.h>
}
#endif

#undef TECHNOLOGY
#undef TRANSPARENT

using SDL::Uint8;

typedef SDL::SDL_Event Event;
typedef SDL::SDL_EventType EventType;
