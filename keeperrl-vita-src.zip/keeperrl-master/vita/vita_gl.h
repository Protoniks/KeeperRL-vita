// PS Vita OpenGL glue: vitaGL is a global C API whose types are #defines.
// This header turns them into typedefs and provides no-op stand-ins for the few
// desktop-GL entry points KeeperRL calls that vitaGL does not implement.
#pragma once
#include <stdint.h>
#include <vitaGL.h>
#include "vita_gl_types.inc"

// Desktop-GL functions vitaGL lacks. (Debug output is compiled out in RELEASE builds anyway.)
typedef void (*GLDEBUGPROC)(GLenum, GLenum, GLuint, GLenum, GLsizei, const GLchar*, const void*);
static inline void glDrawBuffers(GLsizei, const GLenum*) {}  // vitaGL renders to the FBO's colour attachment 0
static inline void glDebugMessageCallback(GLDEBUGPROC, const void*) {}
static inline void glDebugMessageControl(GLenum, GLenum, GLenum, GLsizei, const GLuint*, GLboolean) {}

// Constants vitaGL doesn't define but the game passes around.
#ifndef GL_INVALID_FRAMEBUFFER_OPERATION
#define GL_INVALID_FRAMEBUFFER_OPERATION 0x0506
#endif
#ifndef GL_UNPACK_SKIP_PIXELS
#define GL_UNPACK_SKIP_PIXELS 0x0CF4
#endif
#ifndef GL_UNPACK_SKIP_ROWS
#define GL_UNPACK_SKIP_ROWS 0x0CF3
#endif

// vitaGL's glPixelStorei raises GL_INVALID_ENUM for everything except GL_UNPACK_ROW_LENGTH
// (it always assumes tightly packed rows, which is what the game asks for anyway).
static inline void vita_glPixelStorei(GLenum pname, GLint param) {
  if (pname == GL_UNPACK_ROW_LENGTH)
    ::glPixelStorei(pname, param);
}

// Logs GL errors to ux0:data/KeeperRL/log.txt (defined in vita/vita_platform.cpp).
void vitaLogGlError(unsigned err);

// The game treats any GL error as fatal. On Vita we log instead, so a benign vitaGL quirk
// can't abort the game while real problems still leave a trace for debugging.
static inline GLenum vita_glGetError() {
  GLenum e = ::glGetError();
  if (e != GL_NO_ERROR)
    vitaLogGlError(e);
  return GL_NO_ERROR;
}
