// PS Vita platform layer for KeeperRL.
//
// NOTE: deliberately does not include any SDL header. The game wraps SDL in `namespace SDL { }`
// (see sdl.h) so this interface uses void* for SDL_Event.
#pragma once

#define VITA_SCREEN_W 960
#define VITA_SCREEN_H 544

// Directory for saves/settings, and for log files (created on first start).
#define VITA_USER_DIR "ux0:data/KeeperRL"

// Initializes vitaGL. Call after SDL_Init(VIDEO) / SDL_CreateWindow.
void vitaInitGraphics();
void vitaSwapBuffers();

// Modal error box (replacement for SDL_ShowSimpleMessageBox, which cannot cooperate with vitaGL).
void vitaShowError(const char* text);

// Drop-in replacements for SDL_PollEvent / SDL_WaitEvent that add gamepad -> mouse/keyboard
// emulation. `event` is really an SDL_Event*.
int vitaPollEvent(void* event);
int vitaWaitEvent(void* event);

// Default stack size of new std::threads is small (see vita_platform.cpp); threads that may recurse
// deeply (data loading, world generation) are created through makeThread(), which temporarily
// switches to this size.
#define VITA_BIG_THREAD_STACK (8u * 1024 * 1024)
unsigned vitaSetThreadStackSize(unsigned bytes);  // returns the previous default

void vitaLogGlError(unsigned glErrorCode);
void vitaLogMemory(const char* tag);  // logs newlib heap usage, for tuning VITA_HEAP_MB
void vitaLog(const char* fmt, ...) __attribute__((format(printf, 1, 2)));

// Current emulated cursor position in window pixels (for drawing the software cursor).
void vitaGetCursor(int* x, int* y);
