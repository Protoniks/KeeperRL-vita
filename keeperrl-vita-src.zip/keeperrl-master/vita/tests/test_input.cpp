// Host-side test of the Vita input layer: includes the real vita_platform.cpp and drives it with a fake pad.
#include "../vita_platform.cpp"
#undef main
#include <vector>
#include <cstdio>
#include <cstdlib>

static Uint32 g_ticks = 0;
static SceCtrlData g_pad;
extern "C" Uint32 SDL_GetTicks(void) { return g_ticks; }
extern "C" int SDL_PollEvent(SDL_Event*) { return 0; }
extern "C" int sceCtrlPeekBufferPositive(int, SceCtrlData* d, int) { *d = g_pad; return 1; }

static int failures = 0;
#define EXPECT(cond, msg) do { if (!(cond)) { printf("  FAIL: %s\n", msg); failures++; } else printf("  ok:   %s\n", msg); } while (0)

static void resetPad() { memset(&g_pad, 0, sizeof g_pad); g_pad.lx = g_pad.ly = g_pad.rx = g_pad.ry = 128; }
static std::vector<SDL_Event> step(int ms = 16) {   // advance time, poll until the queue is empty
  g_ticks += ms; std::vector<SDL_Event> v; SDL_Event e;
  while (vitaPollEvent(&e)) v.push_back(e);
  return v;
}
static int count(const std::vector<SDL_Event>& v, Uint32 type) { int n = 0; for (auto& e : v) n += e.type == type; return n; }
static bool hasKey(const std::vector<SDL_Event>& v, Uint32 type, SDL_Keycode k) {
  for (auto& e : v) if (e.type == type && e.key.keysym.sym == k) return true; return false; }
static bool hasButton(const std::vector<SDL_Event>& v, Uint32 type, int b) {
  for (auto& e : v) if (e.type == type && e.button.button == b) return true; return false; }
static int wheelSum(const std::vector<SDL_Event>& v) { int s = 0; for (auto& e : v) if (e.type == SDL_MOUSEWHEEL) s += e.wheel.y; return s; }

int main() {
  int x0, y0, x1, y1;
  printf("idle:\n"); resetPad();
  EXPECT(step().empty(), "no events with centered sticks and no buttons");

  printf("right stick = cursor:\n");
  vitaGetCursor(&x0, &y0); g_pad.rx = 255;
  auto v = step(); vitaGetCursor(&x1, &y1);
  EXPECT(count(v, SDL_MOUSEMOTION) >= 1 && x1 > x0 && y1 == y0, "right stick right -> cursor moves right");
  EXPECT(count(v, SDL_KEYDOWN) == 0, "right stick generates no arrow keys");
  g_pad.rx = 128; g_pad.ry = 0; x0 = x1; y0 = y1; v = step(); vitaGetCursor(&x1, &y1);
  EXPECT(y1 < y0 && x1 == x0, "right stick up -> cursor moves up");
  g_pad.ry = 128; step();

  printf("left stick = arrow keys (not cursor):\n");
  vitaGetCursor(&x0, &y0); g_pad.lx = 255; v = step(); vitaGetCursor(&x1, &y1);
  EXPECT(hasKey(v, SDL_KEYDOWN, SDLK_RIGHT), "left stick right -> RIGHT key down");
  EXPECT(x1 == x0 && y1 == y0 && count(v, SDL_MOUSEMOTION) == 0, "left stick does not move the cursor");
  g_pad.lx = 128; v = step(); EXPECT(hasKey(v, SDL_KEYUP, SDLK_RIGHT), "released -> RIGHT key up");
  g_pad.ly = 0; v = step(); EXPECT(hasKey(v, SDL_KEYDOWN, SDLK_UP), "left stick up -> UP key down");
  g_pad.ly = 128; step();

  printf("L / R = left / right click:\n");
  vitaGetCursor(&x0, &y0); g_pad.buttons = SCE_CTRL_LTRIGGER; v = step();
  EXPECT(hasButton(v, SDL_MOUSEBUTTONDOWN, SDL_BUTTON_LEFT), "L press -> left button down");
  bool atCursor = false; for (auto& e : v) if (e.type == SDL_MOUSEBUTTONDOWN) atCursor = e.button.x == x0 && e.button.y == y0;
  EXPECT(atCursor, "click happens at the cursor position");
  g_pad.rx = 255; v = step(); bool dragState = false;
  for (auto& e : v) if (e.type == SDL_MOUSEMOTION) dragState = (e.motion.state & SDL_BUTTON_LMASK) != 0;
  EXPECT(dragState, "moving the right stick while L is held = drag (left bit set in motion state)");
  g_pad.rx = 128; g_pad.buttons = 0; v = step(); EXPECT(hasButton(v, SDL_MOUSEBUTTONUP, SDL_BUTTON_LEFT), "L release -> left button up");
  g_pad.buttons = SCE_CTRL_RTRIGGER; v = step(); EXPECT(hasButton(v, SDL_MOUSEBUTTONDOWN, SDL_BUTTON_RIGHT), "R press -> right button down");
  g_pad.buttons = 0; v = step(); EXPECT(hasButton(v, SDL_MOUSEBUTTONUP, SDL_BUTTON_RIGHT), "R release -> right button up");
  EXPECT(count(v, SDL_MOUSEWHEEL) == 0, "triggers no longer scroll");

  printf("Cross / Circle = wheel down / up:\n");
  g_pad.buttons = SCE_CTRL_CROSS; v = step(); EXPECT(wheelSum(v) == -1 && count(v, SDL_MOUSEBUTTONDOWN) == 0, "Cross -> wheel down, no click");
  v = step(400); EXPECT(wheelSum(v) < 0, "holding Cross repeats the wheel");
  g_pad.buttons = 0; step();
  g_pad.buttons = SCE_CTRL_CIRCLE; v = step(); EXPECT(wheelSum(v) == +1 && count(v, SDL_MOUSEBUTTONDOWN) == 0, "Circle -> wheel up, no click");
  g_pad.buttons = 0; step();

  printf("unchanged keys:\n");
  struct { unsigned b; SDL_Keycode k; const char* n; } keys[] = {
    {SCE_CTRL_SQUARE, SDLK_RETURN, "Square -> Enter"}, {SCE_CTRL_TRIANGLE, SDLK_SPACE, "Triangle -> Space"},
    {SCE_CTRL_START, SDLK_ESCAPE, "Start -> Escape"}, {SCE_CTRL_UP, SDLK_UP, "D-pad up -> UP"},
    {SCE_CTRL_LEFT, SDLK_LEFT, "D-pad left -> LEFT"}};
  for (auto& t : keys) { g_pad.buttons = t.b; v = step(); EXPECT(hasKey(v, SDL_KEYDOWN, t.k), t.n); g_pad.buttons = 0; v = step(); EXPECT(hasKey(v, SDL_KEYUP, t.k), "  ...and key up on release"); }

  printf("Select layer:\n");
  struct { unsigned b; SDL_Keycode k; const char* n; } sel[] = {
    {SCE_CTRL_CROSS, SDLK_1, "Select+Cross -> 1"}, {SCE_CTRL_CIRCLE, SDLK_2, "Select+Circle -> 2"},
    {SCE_CTRL_SQUARE, SDLK_3, "Select+Square -> 3"}, {SCE_CTRL_TRIANGLE, SDLK_4, "Select+Triangle -> 4"},
    {SCE_CTRL_LTRIGGER, SDLK_t, "Select+L -> T (world map), not a click"}, {SCE_CTRL_RTRIGGER, SDLK_z, "Select+R -> Z, not a click"},
    {SCE_CTRL_UP, SDLK_COMMA, "Select+D-pad up -> ,"}, {SCE_CTRL_DOWN, SDLK_PERIOD, "Select+D-pad down -> ."}};
  for (auto& t : sel) {
    g_pad.buttons = SCE_CTRL_SELECT | t.b; v = step();
    EXPECT(hasKey(v, SDL_KEYDOWN, t.k) && count(v, SDL_MOUSEBUTTONDOWN) == 0 && wheelSum(v) == 0, t.n);
    g_pad.buttons = 0; step();
  }
  printf("latching (release Select before the button):\n");
  g_pad.buttons = SCE_CTRL_SELECT | SCE_CTRL_LTRIGGER; step(); g_pad.buttons = SCE_CTRL_LTRIGGER; v = step();
  EXPECT(count(v, SDL_MOUSEBUTTONDOWN) == 0 && !hasKey(v, SDL_KEYUP, SDLK_t), "T stays held while L is held, no stray click");
  g_pad.buttons = 0; v = step(); EXPECT(hasKey(v, SDL_KEYUP, SDLK_t) && count(v, SDL_MOUSEBUTTONUP) == 0, "T released with L, no stray click-up");

  printf("\n%s (%d failure%s)\n", failures ? "TESTS FAILED" : "ALL INPUT TESTS PASSED", failures, failures == 1 ? "" : "s");
  return failures != 0;
}
