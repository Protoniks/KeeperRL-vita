#!/bin/sh
# Host-side tests of the Vita gamepad -> mouse/keyboard layer and the fps/memory monitor (no Vita needed).
# Compiles the real vita/vita_platform.cpp against the SDK headers with a fake pad and checks the
# events it generates. Usage: VITASDK=/path/to/vitasdk sh vita/tests/run_input_test.sh
set -e
[ -n "$VITASDK" ] || { echo "set VITASDK"; exit 1; }
HERE=$(cd "$(dirname "$0")" && pwd)
T=$(mktemp -d)
V=$VITASDK/arm-vita-eabi/include
mkdir -p $T/inc $T/stub
# expose only the headers we need (the SDK include dir would shadow the host's system headers)
for d in SDL2 psp2 psp2common vitasdk; do ln -s $V/$d $T/inc/$d; done
for f in vitaGL.h vitashark.h; do ln -s $V/$f $T/inc/$f; done
printf 'struct _reent {};\n' > $T/stub/reent.h     # newlib-only header
g++ -std=gnu++14 -fpermissive -w -O0 -no-pie -Dmain=vita_unused_main -I$T/stub -I$T/inc -I$HERE/.. \
    $HERE/test_input.cpp -o $T/test_input -Wl,--unresolved-symbols=ignore-all
g++ -std=gnu++14 -fpermissive -w -O0 -no-pie -Dmain=vita_unused_main -I$T/stub -I$T/inc -I$HERE/.. \
    $HERE/test_perf.cpp -o $T/test_perf -Wl,--unresolved-symbols=ignore-all
# SFO reader: pure code, built with sanitizers so any out-of-bounds read is caught
g++ -std=gnu++14 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all $HERE/test_sfo.cpp -o $T/test_sfo
$VITASDK/bin/vita-mksfoex -s TITLE_ID=TEST00001 "Test" $T/default.sfo
$VITASDK/bin/vita-mksfoex -s TITLE_ID=TEST00001 -d ATTRIBUTE2=4 "Test" $T/attr2_4.sfo
# a real SFO with only the ATTRIBUTE2 key renamed (vita-mksfoex -e writes nothing, so it can't make one)
$VITASDK/bin/vita-mksfoex -s TITLE_ID=ABCD12345 "Test" $T/with_attr2.sfo
python3 -c "import sys; d=open(sys.argv[1],'rb').read(); assert d.count(b'ATTRIBUTE2\\0')==1; open(sys.argv[2],'wb').write(d.replace(b'ATTRIBUTE2\\0', b'ATTRIBUTE9\\0'))" $T/with_attr2.sfo $T/no_attr2.sfo
echo "=== input mapping ==="; $T/test_input
echo; echo "=== frame-rate / memory monitor ==="; $T/test_perf
echo; echo "=== startup param.sfo check (ASan/UBSan) ==="; $T/test_sfo $T/default.sfo $T/attr2_4.sfo $T/no_attr2.sfo "$@"
