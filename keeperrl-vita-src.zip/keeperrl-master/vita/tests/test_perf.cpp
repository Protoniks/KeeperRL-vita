// Host-side test of the Vita frame-rate / memory monitor: includes the real vita_platform.cpp and drives
// it with a fake clock and fake memory numbers.
#include "../vita_platform.cpp"
#undef main
#include <cstdio>
#include <cstdlib>
#include <string>

static uint64_t g_now = 1000000;                 // fake process time (us)
static size_t g_vramFree = 96u << 20, g_vramTotal = 128u << 20, g_ramFree = 12u << 20, g_ramTotal = 16u << 20;
static int g_userFree = 118 << 20;
static int g_swaps = 0;
extern "C" SceUInt64 sceKernelGetProcessTimeWide(void) { return g_now; }
extern "C" void vglSwapBuffers(GLboolean) { g_swaps++; }
extern "C" int sceKernelGetFreeMemorySize(SceKernelFreeMemorySizeInfo* i) {
  i->size_user = g_userFree; i->size_cdram = 90 << 20; i->size_phycont = 4 << 20; return 0; }
extern "C" size_t vglMemFree(vglMemType t) { return t == VGL_MEM_VRAM ? g_vramFree : t == VGL_MEM_RAM ? g_ramFree : 2u << 20; }
extern "C" size_t vglMemTotal(vglMemType t) { return t == VGL_MEM_VRAM ? g_vramTotal : t == VGL_MEM_RAM ? g_ramTotal : 8u << 20; }

static int failures = 0;
static bool has(const std::string& s, const char* sub) { return s.find(sub) != std::string::npos; }
#define EXPECT(cond, msg) do { if (!(cond)) { printf("  FAIL: %s\n    line: %s\n", msg, line.c_str()); failures++; } else printf("  ok:   %s\n", msg); } while (0)

static std::string report(uint64_t intervalUs) { char b[800]; perfBuildLine(b, sizeof b, intervalUs); return b; }
static void frames(int n, uint64_t frameUs) { for (int i = 0; i < n; i++) { g_now += frameUs; vitaSwapBuffers(); } }

int main() {
  std::string line;
  printf("60 fps steady:\n");
  vitaSwapBuffers();                                  // first swap only starts the clock
  frames(60, 16667);
  line = report(60 * 16667);
  EXPECT(has(line, "fps=60.0"), "reports 60.0 fps");
  EXPECT(has(line, "avg=16.7ms"), "avg frame time 16.7 ms");
  EXPECT(has(line, "worst=17ms"), "worst frame 17 ms");
  EXPECT(has(line, "(60 frames/1.0s)"), "frame count and interval shown");
  EXPECT(g_swaps == 61, "every swap reached vglSwapBuffers");

  printf("a stall inside the interval:\n");
  frames(29, 16667); frames(1, 500000); frames(30, 16667);   // one 500 ms hitch
  line = report(29 * 16667 + 500000 + 30 * 16667);
  EXPECT(has(line, "worst=500ms"), "worst frame shows the 500 ms hitch");
  EXPECT(has(line, "fps=") && !has(line, "NO FRAMES"), "still reports fps");

  printf("counters reset, then a loading phase with no frames:\n");
  g_now += 5000000;
  line = report(5000000);
  EXPECT(has(line, "NO FRAMES in the last 5.0s"), "no frames -> says so (loading/stalled)");
  EXPECT(has(line, "loading, world generation"), "explains the likely reasons");

  printf("memory section:\n");
  line = report(1000000);
  char heapCap[32]; snprintf(heapCap, sizeof heapCap, "/%d MB", VITA_HEAP_MB);
  EXPECT(has(line, "heap ") && has(line, heapCap) && has(line, "peak"), "heap usage with capacity (from VITA_HEAP_MB) and peak");
  EXPECT(has(line, "sys free: user 118 MB, cdram 90 MB, phycont 4 MB"), "system free memory");
  EXPECT(!has(line, "vgl free"), "no vitaGL pools before graphics init");
  gGraphicsReady = true;
  line = report(1000000);
  EXPECT(has(line, "vgl free: vram 96/128 MB, ram 12/16 MB"), "vitaGL pools after graphics init");
  EXPECT(!has(line, "!!"), "no warnings when memory is fine");

  printf("warnings:\n");
  g_userFree = 5 << 20;
  line = report(1000000);
  EXPECT(has(line, "SYSTEM RAM LOW"), "low system RAM is flagged");
  g_userFree = 118 << 20;

  printf("robustness:\n");
  char tiny[40]; perfBuildLine(tiny, sizeof tiny, 1000000);
  EXPECT(strlen(tiny) < sizeof tiny, "tiny buffer: truncated and NUL-terminated, no overrun");
  char big[800]; frames(3, 16667); perfBuildLine(big, sizeof big, 3 * 16667);
  line = big;
  EXPECT(strlen(big) < 400, "full line comfortably fits the 800-byte log buffer");

  printf("vitaGL RAM pool sizing (it takes free RAM minus the threshold):\n");
  {
    size_t wanted = VGL_LEGACY_POOL_BYTES + VGL_RAM_POOL_EXTRA;   // 24 MB
    size_t th = vglRamThreshold(100u << 20, wanted);
    EXPECT(th == (100u << 20) - wanted, "100 MB free -> threshold leaves exactly the wanted pool");
    EXPECT((100u << 20) - th == wanted, "resulting vitaGL RAM pool = legacy pool + extra (24 MB)");
    EXPECT(vglRamThreshold(10u << 20, wanted) == 0, "less RAM than wanted -> threshold 0 (no underflow)");
    EXPECT(vglRamThreshold(wanted, wanted) == 0, "exactly enough -> threshold 0");
  }

  printf("thread stack policy:\n");
  EXPECT(_pthread_stack_default_user == VITA_THREAD_STACK_SMALL_KB * 1024u, "default std::thread stack is the small one");
  unsigned prev = vitaSetThreadStackSize(VITA_BIG_THREAD_STACK);
  EXPECT(prev == VITA_THREAD_STACK_SMALL_KB * 1024u && _pthread_stack_default_user == VITA_BIG_THREAD_STACK,
         "makeThread-style switch: returns previous size and applies the big one");
  vitaSetThreadStackSize(prev);
  EXPECT(_pthread_stack_default_user == VITA_THREAD_STACK_SMALL_KB * 1024u, "...and restores the small default afterwards");
  EXPECT(VITA_BIG_THREAD_STACK == 8u * 1024 * 1024 && VITA_THREAD_STACK_SMALL_KB == 1024, "sizes: 8 MB big, 1 MB small");

  printf("\n%s (%d failure%s)\n", failures ? "TESTS FAILED" : "ALL PERF TESTS PASSED", failures, failures == 1 ? "" : "s");
  return failures != 0;
}
