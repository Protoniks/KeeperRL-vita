// Tests for vita/sfo_parse.h (the startup ATTRIBUTE2 check). Run under ASan/UBSan by run_tests.sh.
// usage: test_sfo <default.sfo> <attr2_4.sfo> <no_attr2.sfo> [extra real .sfo files...]
#include "../sfo_parse.h"
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

using Bytes = std::vector<uint8_t>;
static int failures = 0;
#define EXPECT(cond, msg) do { if (!(cond)) { printf("  FAIL: %s\n", msg); failures++; } else printf("  ok:   %s\n", msg); } while (0)

static Bytes readFile(const char* p) {
  Bytes b; FILE* f = fopen(p, "rb"); if (!f) { printf("cannot open %s\n", p); exit(2); }
  uint8_t buf[4096]; size_t n; while ((n = fread(buf, 1, sizeof buf, f)) > 0) b.insert(b.end(), buf, buf + n);
  fclose(f); return b;
}
static bool has(const std::string& s, const char* sub) { return s.find(sub) != std::string::npos; }
static std::string describe(const Bytes& b, int* level) {
  char out[400]; int l = vitasfo::describeAttribute2(b.data(), b.size(), out, sizeof out); if (level) *level = l; return out; }

// Hand-built SFO writer (independent of the parser under test).
struct Entry { std::string key; uint16_t fmt; Bytes val; };
static void put32(Bytes& b, uint32_t v) { for (int i = 0; i < 4; i++) b.push_back((v >> (8 * i)) & 0xFF); }
static void put16(Bytes& b, uint16_t v) { b.push_back(v & 0xFF); b.push_back(v >> 8); }
static Bytes build(const std::vector<Entry>& es) {
  Bytes keys, data, idx;
  for (auto& e : es) {
    put16(idx, (uint16_t)keys.size()); put16(idx, e.fmt); put32(idx, (uint32_t)e.val.size());
    put32(idx, (uint32_t)e.val.size()); put32(idx, (uint32_t)data.size());
    keys.insert(keys.end(), e.key.begin(), e.key.end()); keys.push_back(0);
    data.insert(data.end(), e.val.begin(), e.val.end());
  }
  Bytes b = {0, 'P', 'S', 'F'}; put32(b, 0x101);
  uint32_t kt = 20 + (uint32_t)idx.size(); put32(b, kt); put32(b, kt + (uint32_t)keys.size()); put32(b, (uint32_t)es.size());
  b.insert(b.end(), idx.begin(), idx.end()); b.insert(b.end(), keys.begin(), keys.end()); b.insert(b.end(), data.begin(), data.end());
  return b;
}
static Entry u32(const char* k, uint32_t v) { Bytes b; put32(b, v); return {k, vitasfo::FMT_UINT32, b}; }
static Entry str(const char* k, const char* v) { Bytes b(v, v + strlen(v)); b.push_back(0); return {k, vitasfo::FMT_UTF8, b}; }

int main(int argc, char** argv) {
  if (argc < 4) { printf("usage: test_sfo default.sfo attr2_4.sfo no_attr2.sfo [more.sfo...]\n"); return 2; }
  int level; std::string line;

  printf("real SFOs made by the SDK's vita-mksfoex:\n");
  Bytes def = readFile(argv[1]); line = describe(def, &level);
  EXPECT(level == 0 && has(line, "ATTRIBUTE2=0x0000000C") && has(line, "+109 MiB") && has(line, "as intended"), "default SFO (ATTRIBUTE2=12) -> as intended, +109 MiB");
  EXPECT(has(line, "TITLE_ID=") && !has(line, "TITLE_ID=?"), "title id is read");
  Bytes a4 = readFile(argv[2]); line = describe(a4, &level);
  EXPECT(level == 1 && has(line, "0x00000004") && has(line, "+29 MiB") && has(line, "WARNING"), "ATTRIBUTE2=4 -> warning, +29 MiB only");
  Bytes none = readFile(argv[3]); line = describe(none, &level);
  EXPECT(level == 1 && has(line, "MISSING") && has(line, "WARNING") && has(line, "TITLE_ID=ABCD12345"), "no ATTRIBUTE2 -> MISSING warning (title still read)");
  for (int i = 4; i < argc; i++) { Bytes x = readFile(argv[i]); line = describe(x, &level); printf("  info: %s -> %s\n", argv[i], line.c_str()); }

  printf("hand-built SFOs:\n");
  line = describe(build({str("TITLE_ID", "TEST00001"), u32("ATTRIBUTE2", 8)}), &level);
  EXPECT(level == 1 && has(line, "+77 MiB"), "ATTRIBUTE2=8 -> +77 MiB, warning");
  line = describe(build({str("TITLE_ID", "TEST00001"), u32("ATTRIBUTE2", 12 | 0x10000)}), &level);
  EXPECT(level == 0 && has(line, "+109 MiB"), "extra unrelated bits with 0x0C set still count as enlarged memory");
  line = describe(build({u32("ATTRIBUTE2", 12)}), &level);
  EXPECT(level == 0 && has(line, "TITLE_ID=?"), "missing TITLE_ID does not break the ATTRIBUTE2 check");
  line = describe(build({str("TITLE_ID", "TEST00001"), str("ATTRIBUTE2", "12")}), &level);
  EXPECT(level == 1 && has(line, "MISSING"), "ATTRIBUTE2 with the wrong type (string) is treated as missing");
  uint32_t v = 0;
  EXPECT(vitasfo::getUint32(build({str("ATTRIBUTE2X", "x"), u32("ATTRIBUTE2", 12)}).data(), build({str("ATTRIBUTE2X", "x"), u32("ATTRIBUTE2", 12)}).size(), "ATTRIBUTE2", &v) && v == 12,
         "a key that merely starts with the same letters is not confused with ATTRIBUTE2");
  char small[4]; Bytes tid = build({str("TITLE_ID", "KRLVT0001")});
  EXPECT(vitasfo::getString(tid.data(), tid.size(), "TITLE_ID", small, sizeof small) && strcmp(small, "KRL") == 0, "string output is truncated safely to a small buffer");

  printf("not an SFO:\n");
  EXPECT(describe(Bytes(), &level).size() && level == 2, "empty file -> unreadable (level 2)");
  EXPECT(describe(Bytes(100, 0xFF), &level).size() && level == 2, "garbage -> unreadable");
  EXPECT(describe(Bytes{'P', 'K', 3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, &level).size() && level == 2, "a zip header -> unreadable");

  printf("malformed input sweep (run under ASan/UBSan: any out-of-bounds read aborts the test):\n");
  long checked = 0;
  for (Bytes* real : {&def, &a4, &none}) {
    for (size_t cut = 0; cut <= real->size(); cut++) { Bytes t(real->begin(), real->begin() + cut); describe(t, nullptr); checked++; }  // every truncation
    for (size_t i = 0; i < real->size(); i++) {                                       // every single byte corrupted
      for (int pat : {0x00, 0xFF, 0x7F, 0x80}) { Bytes t = *real; t[i] = (uint8_t)pat; describe(t, nullptr); checked++; }
    }
    for (size_t i = 0; i + 4 <= 64 && i + 4 <= real->size(); i += 4) {                // huge 32-bit fields in the header/index
      for (uint32_t big : {0xFFFFFFFFu, 0x80000000u, 0x7FFFFFFFu, 0x10000u}) { Bytes t = *real; for (int k = 0; k < 4; k++) t[i + k] = (big >> (8 * k)) & 0xFF; describe(t, nullptr); checked++; }
    }
  }
  printf("  ok:   %ld malformed variants handled without crashing\n", checked);

  printf("\n%s (%d failure%s)\n", failures ? "TESTS FAILED" : "ALL SFO TESTS PASSED", failures, failures == 1 ? "" : "s");
  return failures != 0;
}
