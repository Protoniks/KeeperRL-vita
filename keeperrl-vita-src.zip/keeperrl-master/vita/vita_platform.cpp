// PS Vita platform layer for KeeperRL: startup, memory config, graphics init, input emulation.
//
// Controls (see README-VITA.md):
//   Right stick ....... move mouse cursor           Touch screen .... tap/drag = left click/drag
//   L ................. left click                  R ............... right click
//   Left stick / D-pad  arrow keys (scroll map, menus, walk)
//   Cross / Circle .... mouse wheel down / up       Square .......... Enter
//   Triangle .......... Space (pause)               Start ........... Escape (menu / cancel)
//   Select (held) modifies:  Cross/Circle/Square/Triangle = keys 1/2/3/4 (game speed),
//                            D-pad up/down = , and . (z-levels),  L = T (world map),  R = Z (zoom)

#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>

#include <psp2/kernel/processmgr.h>
#include <psp2/kernel/sysmem.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/ctrl.h>
#include <psp2/power.h>
#include <psp2/io/stat.h>
#include <psp2/common_dialog.h>
#include <psp2/message_dialog.h>
#include <vitaGL.h>

#include <malloc.h>
#include <atomic>
#include <cstdint>
#include <pthread.h>
#include <deque>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <cmath>

#include "vita_platform.h"
#include "sfo_parse.h"

// ---------------------------------------------------------------------------------------------
// libstdc++ decides whether threading is "active" by testing whether the weak symbol pthread_cancel
// got linked in. In a static link nothing pulls it in, so std::thread throws ("Enable multithreading
// to use std::thread") and std::mutex / condition_variable silently become no-ops. A strong reference
// here forces libpthread's pthread_cancel into the executable.
// ---------------------------------------------------------------------------------------------
extern "C" int pthread_cancel(pthread_t);
static void* const kKeepPthreadActive[] __attribute__((used)) = {(void*)&pthread_cancel};

// ---------------------------------------------------------------------------------------------
// Memory configuration. Tune these if the game runs out of memory or vitaGL fails to allocate.
// ---------------------------------------------------------------------------------------------
#define VITA_HEAP_MB 160                       // newlib malloc heap (game data, world model)
#define VITA_THREAD_STACK_SMALL_KB 1024        // default stack for std::threads (audio streamer, uploads, OpenAL)
#define VITA_MAIN_STACK_MB 8                   // stack of the thread the whole game runs on
#define VGL_LEGACY_POOL_BYTES 0x800000         // 8 MB: pool for glBegin/glEnd + client vertex arrays
#define VGL_RAM_POOL_EXTRA 0x1000000           // 16 MB more RAM for vitaGL's other buffers; textures use video memory

extern "C" {
int _newlib_heap_size_user = VITA_HEAP_MB * 1024 * 1024;
unsigned int _pthread_stack_default_user = VITA_THREAD_STACK_SMALL_KB * 1024;
}

unsigned vitaSetThreadStackSize(unsigned bytes) {
  unsigned previous = _pthread_stack_default_user;
  _pthread_stack_default_user = bytes;
  return previous;
}

// mbedTLS (pulled in by libcurl) asks newlib for entropy; the Vita kernel has an RNG for this.
#include <psp2/kernel/rng.h>
#include <reent.h>
extern "C" int _getentropy_r(struct _reent*, void* buf, size_t len) {
  return sceKernelGetRandomNumber(buf, len) < 0 ? -1 : 0;
}

// ---------------------------------------------------------------------------------------------
// Logging
// ---------------------------------------------------------------------------------------------
void vitaLog(const char* fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vfprintf(stderr, fmt, ap);
  va_end(ap);
  fputc('\n', stderr);
  fflush(stderr);
}

// ---------------------------------------------------------------------------------------------
// Performance / memory monitor. A low-priority background thread writes one "[perf]" line to
// log.txt every PERF_LOG_INTERVAL_S seconds: frame rate, worst frame time, game heap, system free
// memory and vitaGL memory pools. Frames are counted in vitaSwapBuffers().
// If no frame was presented during the interval the line says so (loading / world generation /
// stalled), which is the most useful hint when the game seems frozen.
// ---------------------------------------------------------------------------------------------
#define PERF_LOG_INTERVAL_S 5

namespace {

std::atomic<uint32_t> gFrames{0};
std::atomic<uint64_t> gFrameSumUs{0};
std::atomic<uint64_t> gFrameWorstUs{0};
std::atomic<uint64_t> gLastSwapUs{0};
std::atomic<uint32_t> gHeapPeakKB{0};
std::atomic<bool> gGraphicsReady{false};

double mb(double bytes) {
  return bytes / (1024.0 * 1024.0);
}

// Bounded printf-append: never overruns buf, always NUL-terminated.
void appendf(char* buf, size_t n, size_t* len, const char* fmt, ...) {
  if (*len + 1 >= n)
    return;
  va_list ap;
  va_start(ap, fmt);
  int w = vsnprintf(buf + *len, n - *len, fmt, ap);
  va_end(ap);
  if (w > 0)
    *len = (*len + (size_t)w < n) ? *len + (size_t)w : n - 1;
}

void updateHeapPeak() {
  struct mallinfo mi = mallinfo();
  uint32_t kb = (uint32_t)(mi.uordblks / 1024);
  uint32_t peak = gHeapPeakKB.load();
  while (kb > peak && !gHeapPeakKB.compare_exchange_weak(peak, kb)) {}
}

// The memory half of a log line: game heap, system free RAM, vitaGL pools, and warnings.
void memoryText(char* buf, size_t n) {
  size_t len = 0;
  buf[0] = 0;
  struct mallinfo mi = mallinfo();
  updateHeapPeak();
  appendf(buf, n, &len, "heap %.1f/%d MB (peak %.1f)", mb(mi.uordblks), VITA_HEAP_MB,
          mb(gHeapPeakKB.load() * 1024.0));
  SceKernelFreeMemorySizeInfo sys;
  memset(&sys, 0, sizeof(sys));
  sys.size = sizeof(sys);
  bool haveSys = sceKernelGetFreeMemorySize(&sys) >= 0;
  if (haveSys)
    appendf(buf, n, &len, " | sys free: user %.0f MB, cdram %.0f MB, phycont %.0f MB", mb(sys.size_user),
            mb(sys.size_cdram), mb(sys.size_phycont));
  if (gGraphicsReady)
    appendf(buf, n, &len, " | vgl free: vram %.0f/%.0f MB, ram %.0f/%.0f MB, phycont %.0f/%.0f MB",
            mb(vglMemFree(VGL_MEM_VRAM)), mb(vglMemTotal(VGL_MEM_VRAM)), mb(vglMemFree(VGL_MEM_RAM)),
            mb(vglMemTotal(VGL_MEM_RAM)), mb(vglMemFree(VGL_MEM_PHYCONT)), mb(vglMemTotal(VGL_MEM_PHYCONT)));
  if (mi.uordblks > 0.9 * VITA_HEAP_MB * 1024.0 * 1024.0)
    appendf(buf, n, &len, " !! HEAP NEARLY FULL");
  if (haveSys && sys.size_user < 8 * 1024 * 1024)
    appendf(buf, n, &len, " !! SYSTEM RAM LOW (<8 MB free)");
}

// Builds the complete "[perf]" line and resets the frame counters. intervalUs = time since the
// previous report.
void perfBuildLine(char* buf, size_t n, uint64_t intervalUs) {
  uint32_t frames = gFrames.exchange(0);
  uint64_t sumUs = gFrameSumUs.exchange(0);
  uint64_t worstUs = gFrameWorstUs.exchange(0);
  double secs = intervalUs / 1e6;
  size_t len = 0;
  buf[0] = 0;
  if (frames > 0)
    appendf(buf, n, &len, "[perf] fps=%.1f avg=%.1fms worst=%.0fms (%u frames/%.1fs)", frames / secs,
            sumUs / 1000.0 / frames, worstUs / 1000.0, (unsigned)frames, secs);
  else
    appendf(buf, n, &len, "[perf] NO FRAMES in the last %.1fs (loading, world generation, or stalled)", secs);
  appendf(buf, n, &len, " | ");
  char mem[480];
  memoryText(mem, sizeof(mem));
  appendf(buf, n, &len, "%s", mem);
}

void perfOnFrame() {
  uint64_t now = sceKernelGetProcessTimeWide();
  uint64_t last = gLastSwapUs.exchange(now);
  if (!last) {
    vitaLog("[perf] first frame presented %.1fs after process start", now / 1e6);
    return;
  }
  uint64_t dt = now - last;
  gFrames.fetch_add(1);
  gFrameSumUs.fetch_add(dt);
  uint64_t worst = gFrameWorstUs.load();
  while (dt > worst && !gFrameWorstUs.compare_exchange_weak(worst, dt)) {}
}

int perfThread(SceSize, void*) {
  uint64_t startUs = sceKernelGetProcessTimeWide();
  uint64_t lastReport = startUs;
  for (;;) {
    sceKernelDelayThread(1000 * 1000);
    updateHeapPeak();  // sample every second so short spikes are not missed
    uint64_t now = sceKernelGetProcessTimeWide();
    // report every 2 s during the first minute (startup is where things go wrong), then every 5 s
    uint64_t intervalS = (now - startUs < 60ull * 1000000ull) ? 2 : PERF_LOG_INTERVAL_S;
    if (now - lastReport >= intervalS * 1000000ull) {
      char line[800];
      perfBuildLine(line, sizeof(line), now - lastReport);
      vitaLog("%s", line);
      lastReport = now;
    }
  }
  return 0;
}

}  // namespace

// Startup check: reads the *installed* param.sfo (app0:sce_sys/param.sfo) and logs whether it carries the
// "enlarged memory" bits in ATTRIBUTE2. A param.sfo swapped in from another homebrew may lack them, which
// would silently cost the app a large amount of RAM. This only inspects the file; the [mem] lines show how
// much memory the system really gave us.
static void logParamSfo() {
  static uint8_t buf[65536];
  FILE* f = fopen("app0:sce_sys/param.sfo", "rb");
  if (!f)
    f = fopen("app0:/sce_sys/param.sfo", "rb");  // both path styles are used on Vita
  if (!f) {
    vitaLog("[sfo] could not open app0:sce_sys/param.sfo: cannot verify ATTRIBUTE2");
    return;
  }
  size_t n = fread(buf, 1, sizeof(buf), f);
  fclose(f);
  char line[400];
  vitasfo::describeAttribute2(buf, n, line, sizeof(line));
  vitaLog("%s", line);
}

void vitaLogMemory(const char* tag) {
  char mem[480];
  memoryText(mem, sizeof(mem));
  vitaLog("[mem] %s: %s", tag, mem);
}

void vitaLogGlError(unsigned err) {
  static int count = 0;
  if (count++ < 200)  // don't flood the memory card
    vitaLog("GL error 0x%04X", err);
}

// ---------------------------------------------------------------------------------------------
// Graphics
// ---------------------------------------------------------------------------------------------
// Same value vitaGL's own vglInitExtended() passes for the "common dialog" memory pool.
#define VGL_CDIALOG_POOL_BYTES 0x8C6000

namespace {
// vitaGL claims (free RAM - threshold) for its own RAM pool. We want it to take only what it needs, so
// that the rest stays available to the game heap's neighbours (thread stacks, audio, the system).
size_t vglRamThreshold(size_t freeUser, size_t ramPoolWanted) {
  return freeUser > ramPoolWanted ? freeUser - ramPoolWanted : 0;
}
}  // namespace

void vitaInitGraphics() {
  SDL_SetHint(SDL_HINT_TOUCH_MOUSE_EVENTS, "1");
  SceKernelFreeMemorySizeInfo info;
  memset(&info, 0, sizeof(info));
  info.size = sizeof(info);
  sceKernelGetFreeMemorySize(&info);
  size_t wanted = VGL_LEGACY_POOL_BYTES + VGL_RAM_POOL_EXTRA;
  size_t threshold = vglRamThreshold(info.size_user, wanted);
  vitaLog("[mem] before vitaGL init: user free %.0f MB, cdram %.0f MB, phycont %.0f MB -> vitaGL RAM pool %.0f MB",
          mb(info.size_user), mb(info.size_cdram), mb(info.size_phycont), mb(info.size_user - threshold));
  // NOTE: the return value is NOT a success flag. It is GL_TRUE only when the requested resolution had
  // to be reduced to the maximum the display supports (so GL_FALSE is the normal case).
  GLboolean resolutionFallback =
      vglInitWithCustomThreshold(VGL_LEGACY_POOL_BYTES, VITA_SCREEN_W, VITA_SCREEN_H, (int)threshold, 0, 0,
                                 VGL_CDIALOG_POOL_BYTES, SCE_GXM_MULTISAMPLE_NONE);
  gGraphicsReady = true;
  vitaLog("vitaGL initialized (resolution fallback: %s; video memory pool %.0f MB)",
          resolutionFallback ? "yes" : "no", mb(vglMemTotal(VGL_MEM_VRAM)));
  if (vglMemTotal(VGL_MEM_VRAM) == 0)
    vitaLog("WARNING: vitaGL has no video memory pool");
  vglWaitVblankStart(GL_TRUE);
}

void vitaSwapBuffers() {
  vglSwapBuffers(GL_FALSE);
  perfOnFrame();
}

void vitaShowError(const char* text) {
  vitaLog("ERROR: %s", text);
  char buf[512];
  snprintf(buf, sizeof(buf), "%s", text);  // the dialog has a length limit
  SceMsgDialogUserMessageParam msg;
  memset(&msg, 0, sizeof(msg));
  msg.buttonType = SCE_MSG_DIALOG_BUTTON_TYPE_OK;
  msg.msg = (const SceChar8*)buf;
  SceMsgDialogParam param;
  sceMsgDialogParamInit(&param);
  param.mode = SCE_MSG_DIALOG_MODE_USER_MSG;
  param.userMsgParam = &msg;
  if (sceMsgDialogInit(&param) < 0)
    return;
  while (sceMsgDialogGetStatus() == SCE_COMMON_DIALOG_STATUS_RUNNING) {
    glClear(GL_COLOR_BUFFER_BIT);
    vglSwapBuffers(GL_TRUE);  // GL_TRUE: let the system draw the common dialog
  }
  sceMsgDialogTerm();
}

// ---------------------------------------------------------------------------------------------
// Input: gamepad -> mouse / keyboard events
// ---------------------------------------------------------------------------------------------
namespace {

enum VKey {
  K_UP, K_DOWN, K_LEFT, K_RIGHT, K_ESC, K_ENTER, K_SPACE, K_COMMA, K_PERIOD,
  K_1, K_2, K_3, K_4, K_T, K_Z, K_COUNT
};

struct KeyInfo { SDL_Scancode scancode; SDL_Keycode sym; bool repeats; };

const KeyInfo kKeys[K_COUNT] = {
  {SDL_SCANCODE_UP, SDLK_UP, true},          {SDL_SCANCODE_DOWN, SDLK_DOWN, true},
  {SDL_SCANCODE_LEFT, SDLK_LEFT, true},      {SDL_SCANCODE_RIGHT, SDLK_RIGHT, true},
  {SDL_SCANCODE_ESCAPE, SDLK_ESCAPE, false}, {SDL_SCANCODE_RETURN, SDLK_RETURN, false},
  {SDL_SCANCODE_SPACE, SDLK_SPACE, false},   {SDL_SCANCODE_COMMA, SDLK_COMMA, true},
  {SDL_SCANCODE_PERIOD, SDLK_PERIOD, true},  {SDL_SCANCODE_1, SDLK_1, false},
  {SDL_SCANCODE_2, SDLK_2, false},           {SDL_SCANCODE_3, SDLK_3, false},
  {SDL_SCANCODE_4, SDLK_4, false},           {SDL_SCANCODE_T, SDLK_t, false},
  {SDL_SCANCODE_Z, SDLK_z, false},
};

// What a button does. Normal action, and the action while Select is held.
struct Action {
  enum Type { NONE, MOUSE, KEY, WHEEL } type;
  int arg;  // SDL_BUTTON_*, VKey, or wheel direction
};

struct ButtonMap {
  unsigned sceButton;
  Action normal;
  Action withSelect;
};

const ButtonMap kButtons[] = {
  {SCE_CTRL_CROSS,    {Action::WHEEL, -1},               {Action::KEY, K_1}},
  {SCE_CTRL_CIRCLE,   {Action::WHEEL, +1},               {Action::KEY, K_2}},
  {SCE_CTRL_SQUARE,   {Action::KEY, K_ENTER},            {Action::KEY, K_3}},
  {SCE_CTRL_TRIANGLE, {Action::KEY, K_SPACE},            {Action::KEY, K_4}},
  {SCE_CTRL_LTRIGGER, {Action::MOUSE, SDL_BUTTON_LEFT},  {Action::KEY, K_T}},
  {SCE_CTRL_RTRIGGER, {Action::MOUSE, SDL_BUTTON_RIGHT}, {Action::KEY, K_Z}},
  {SCE_CTRL_START,    {Action::KEY, K_ESC},              {Action::KEY, K_ESC}},
};
const int kNumButtons = sizeof(kButtons) / sizeof(kButtons[0]);

std::deque<SDL_Event> gQueue;
float gCursorX = VITA_SCREEN_W / 2, gCursorY = VITA_SCREEN_H / 2;
unsigned gPrevButtons = 0;
Uint32 gLastPumpTicks = 0;
Uint32 gMouseMask = 0;
Action gActive[kNumButtons];           // action each button started with (latched until release)
bool gKeyDown[K_COUNT] = {};
Uint32 gNextRepeat[K_COUNT] = {};
Uint32 gNextWheel = 0;

void pushMouseButton(int button, bool down) {
  SDL_Event e;
  memset(&e, 0, sizeof(e));
  e.type = down ? SDL_MOUSEBUTTONDOWN : SDL_MOUSEBUTTONUP;
  e.button.timestamp = SDL_GetTicks();
  e.button.windowID = 1;
  e.button.button = button;
  e.button.state = down ? SDL_PRESSED : SDL_RELEASED;
  e.button.clicks = 1;
  e.button.x = (int)gCursorX;
  e.button.y = (int)gCursorY;
  Uint32 bit = SDL_BUTTON(button);
  gMouseMask = down ? (gMouseMask | bit) : (gMouseMask & ~bit);
  gQueue.push_back(e);
}

void pushMotion(int dx, int dy) {
  SDL_Event e;
  memset(&e, 0, sizeof(e));
  e.type = SDL_MOUSEMOTION;
  e.motion.timestamp = SDL_GetTicks();
  e.motion.windowID = 1;
  e.motion.state = gMouseMask;
  e.motion.x = (int)gCursorX;
  e.motion.y = (int)gCursorY;
  e.motion.xrel = dx;
  e.motion.yrel = dy;
  gQueue.push_back(e);
}

void pushWheel(int dir) {
  SDL_Event e;
  memset(&e, 0, sizeof(e));
  e.type = SDL_MOUSEWHEEL;
  e.wheel.timestamp = SDL_GetTicks();
  e.wheel.windowID = 1;
  e.wheel.y = dir;
  e.wheel.direction = SDL_MOUSEWHEEL_NORMAL;
  gQueue.push_back(e);
}

void pushKey(VKey k, bool down, bool repeat) {
  SDL_Event e;
  memset(&e, 0, sizeof(e));
  e.type = down ? SDL_KEYDOWN : SDL_KEYUP;
  e.key.timestamp = SDL_GetTicks();
  e.key.windowID = 1;
  e.key.state = down ? SDL_PRESSED : SDL_RELEASED;
  e.key.repeat = repeat;
  e.key.keysym.scancode = kKeys[k].scancode;
  e.key.keysym.sym = kKeys[k].sym;
  e.key.keysym.mod = KMOD_NONE;
  gQueue.push_back(e);
}

// Applies the desired state of a key, emitting down / repeat / up events as needed.
void updateKey(VKey k, bool want, Uint32 now) {
  if (want && !gKeyDown[k]) {
    gKeyDown[k] = true;
    gNextRepeat[k] = now + 350;
    pushKey(k, true, false);
  } else if (want && kKeys[k].repeats && now >= gNextRepeat[k]) {
    gNextRepeat[k] = now + 60;
    pushKey(k, true, true);
  } else if (!want && gKeyDown[k]) {
    gKeyDown[k] = false;
    pushKey(k, false, false);
  }
}

float stickAxis(unsigned char raw) {
  float v = (raw - 128) / 128.0f;
  const float dead = 0.18f;
  if (std::fabs(v) < dead)
    return 0;
  float s = (std::fabs(v) - dead) / (1.0f - dead);
  return v < 0 ? -s : s;
}

void pumpGamepad() {
  Uint32 now = SDL_GetTicks();
  if (now == gLastPumpTicks)
    return;
  float dt = (now - gLastPumpTicks) / 1000.0f;
  if (dt > 0.05f)
    dt = 0.05f;
  gLastPumpTicks = now;

  SceCtrlData pad;
  memset(&pad, 0, sizeof(pad));
  if (sceCtrlPeekBufferPositive(0, &pad, 1) <= 0)
    return;
  unsigned buttons = pad.buttons;
  bool select = buttons & SCE_CTRL_SELECT;

  // --- Right stick: cursor. Response curve is quadratic so small deflections stay precise.
  float mx = stickAxis(pad.rx), my = stickAxis(pad.ry);
  if (mx != 0 || my != 0) {
    const float speed = 900.0f;  // pixels per second at full deflection
    float nx = gCursorX + mx * std::fabs(mx) * speed * dt;
    float ny = gCursorY + my * std::fabs(my) * speed * dt;
    nx = std::fmin(std::fmax(nx, 0.0f), VITA_SCREEN_W - 1.0f);
    ny = std::fmin(std::fmax(ny, 0.0f), VITA_SCREEN_H - 1.0f);
    int dx = (int)nx - (int)gCursorX, dy = (int)ny - (int)gCursorY;
    gCursorX = nx;
    gCursorY = ny;
    if (dx || dy)
      pushMotion(dx, dy);
  }

  // --- Buttons with latched actions.
  bool want[K_COUNT] = {};
  for (int i = 0; i < kNumButtons; ++i) {
    bool held = buttons & kButtons[i].sceButton;
    bool wasHeld = gPrevButtons & kButtons[i].sceButton;
    if (held && !wasHeld) {
      gActive[i] = select ? kButtons[i].withSelect : kButtons[i].normal;
      if (gActive[i].type == Action::MOUSE)
        pushMouseButton(gActive[i].arg, true);
      else if (gActive[i].type == Action::WHEEL) {
        pushWheel(gActive[i].arg);
        gNextWheel = now + 350;
      }
    } else if (!held && wasHeld) {
      if (gActive[i].type == Action::MOUSE)
        pushMouseButton(gActive[i].arg, false);
      gActive[i].type = Action::NONE;
    }
    if (held && gActive[i].type == Action::KEY)
      want[gActive[i].arg] = true;
    if (held && gActive[i].type == Action::WHEEL && now >= gNextWheel) {
      pushWheel(gActive[i].arg);
      gNextWheel = now + 90;
    }
  }

  // --- D-pad and left stick: arrow keys (Select+up/down = z-level keys).
  float ax = stickAxis(pad.lx), ay = stickAxis(pad.ly);
  bool up = (buttons & SCE_CTRL_UP), down = (buttons & SCE_CTRL_DOWN);
  if (select) {
    want[K_COMMA] |= up;
    want[K_PERIOD] |= down;
    up = down = false;
  }
  want[K_UP] |= up || ay < -0.5f;
  want[K_DOWN] |= down || ay > 0.5f;
  want[K_LEFT] |= (buttons & SCE_CTRL_LEFT) || ax < -0.5f;
  want[K_RIGHT] |= (buttons & SCE_CTRL_RIGHT) || ax > 0.5f;

  for (int k = 0; k < K_COUNT; ++k)
    updateKey((VKey)k, want[k], now);
  gPrevButtons = buttons;
}

}  // namespace

int vitaPollEvent(void* eventPtr) {
  SDL_Event* event = (SDL_Event*)eventPtr;
  if (gQueue.empty())
    pumpGamepad();
  if (!gQueue.empty()) {
    *event = gQueue.front();
    gQueue.pop_front();
    return 1;
  }
  if (!SDL_PollEvent(event))
    return 0;
  // Keep the emulated cursor in sync with the touch screen (SDL turns touches into mouse events).
  if (event->type == SDL_MOUSEMOTION) {
    gCursorX = event->motion.x;
    gCursorY = event->motion.y;
  } else if (event->type == SDL_MOUSEBUTTONDOWN || event->type == SDL_MOUSEBUTTONUP) {
    gCursorX = event->button.x;
    gCursorY = event->button.y;
  }
  return 1;
}

int vitaWaitEvent(void* eventPtr) {
  while (!vitaPollEvent(eventPtr))
    SDL_Delay(4);
  return 1;
}

void vitaGetCursor(int* x, int* y) {
  *x = (int)gCursorX;
  *y = (int)gCursorY;
}

// ---------------------------------------------------------------------------------------------
// Entry point: set up the system, then run the game on a thread with a big stack.
// ---------------------------------------------------------------------------------------------
extern int keeperEntry(int argc, char** argv);  // the game's original main(), see main.cpp

namespace {
struct EntryArgs { int argc; char** argv; int result; };

int gameThread(SceSize, void* argp) {
  EntryArgs* args = *(EntryArgs**)argp;
  args->result = keeperEntry(args->argc, args->argv);
  return 0;
}
}  // namespace

int main(int argc, char** argv) {
  scePowerSetArmClockFrequency(444);
  scePowerSetBusClockFrequency(222);
  scePowerSetGpuClockFrequency(222);
  scePowerSetGpuXbarClockFrequency(166);
  sceIoMkdir("ux0:data", 0777);
  sceIoMkdir(VITA_USER_DIR, 0777);
  sceIoMkdir(VITA_USER_DIR "/data", 0777);  // where the (optional, user-supplied) paid data goes
  freopen(VITA_USER_DIR "/log.txt", "w", stderr);
  static char logBuffer[4096];
  setvbuf(stderr, logBuffer, _IOLBF, sizeof(logBuffer));  // flush every line: a crash must not lose the tail
  sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG_WIDE);
  vitaLog("KeeperRL for PS Vita starting (heap %d MB)", VITA_HEAP_MB);
  logParamSfo();
  vitaLogMemory("process start");

  // Always run with --stderr so the game's INFO messages end up in log.txt (helps debugging a port
  // that has never been run on real hardware). Remove once the port is stable.
  static char* extendedArgv[] = {(char*)"eboot.bin", (char*)"--stderr", nullptr};
  SceUID perf = sceKernelCreateThread("KeeperRL-perf", perfThread, 0x60, 128 * 1024, 0, 0, nullptr);
  if (perf >= 0)
    sceKernelStartThread(perf, 0, nullptr);
  EntryArgs args = {2, extendedArgv, 0};
  (void)argc;
  (void)argv;
  EntryArgs* argsPtr = &args;
  SceUID thread = sceKernelCreateThread("KeeperRL", gameThread, 0x40, VITA_MAIN_STACK_MB * 1024 * 1024, 0, 0, nullptr);
  if (thread < 0) {
    vitaLog("sceKernelCreateThread failed: 0x%08X", thread);
    sceKernelExitProcess(1);
  }
  sceKernelStartThread(thread, sizeof(argsPtr), &argsPtr);
  sceKernelWaitThreadEnd(thread, nullptr, nullptr);
  vitaLog("KeeperRL exited with code %d", args.result);
  sceKernelExitProcess(args.result);
  return args.result;
}
