# KeeperRL for PS Vita (experimental port)

An unofficial, experimental port of the open-source KeeperRL code base to the PlayStation Vita
(HENkaku/Enso-style homebrew, VitaSDK). **It compiles, links and packages into a VPK, but it has
never been run on real hardware or an emulator.** Expect to debug things.
Please report what you see (see "If it crashes" below).

## What works / what to expect

* Runs in KeeperRL's built-in **free (ASCII) mode**: the game's real art, sound and music are a
  proprietary `data/` folder that is not part of the open-source repository.
* 512 MB of RAM is tight for KeeperRL. Start with small worlds. Loading the game data at startup
  will be slow on the Vita's 444 MHz CPU (expect a long black/loading screen).
* Networking is disabled (no online mods, bug reports, uploads, or "personal message").
* Steam features (achievements, Steam Input, workshop) are stubbed out.
* Naming your keeper uses the on-screen text field with the system keyboard (untested).

## Controls

| Vita | Action |
|------|--------|
| Right stick | Move the mouse cursor |
| Touch screen | Tap / drag = left click / drag |
| L | Left click (hold L + move the right stick = drag) |
| R | Right click |
| Left stick, D-pad | Arrow keys (scroll map, menus, walk) |
| ✕ Cross / ○ Circle | Mouse wheel down / up (scroll lists, zoom) |
| □ Square | Enter (menu confirm) |
| △ Triangle | Space (pause / unpause) |
| Start | Escape (menu / cancel) |
| Select + ✕ ○ □ △ | Keys 1 2 3 4 (game speed) |
| Select + D-pad up/down | `,` and `.` (change z-level) |
| Select + L / R | `T` (world map) / `Z` (zoom map) |

## Paid data

The game's real art, sound and music are not part of the open-source repository, so if you own them
you supply them yourself. Copy your `data` folder to **`ux0:data/KeeperRL/data`** (with VitaShell or
FTP; the folder is created empty on first run so it is easy to find). This is separate from the
app's own install folder, so it survives reinstalling or updating the VPK, and you never need to
repack anything to add or update it.

This has not been tried with the real paid data: memory is the likely limiting factor (see "Memory",
above). If textures don't fit, expect missing/garbled sprites rather than a crash, logged as GL
errors.

## Installing

1. Copy `KeeperRL.vpk` to the Vita and install it with VitaShell.
2. Saves, settings and a log are stored in `ux0:data/KeeperRL/`.
   `log.txt` holds startup messages, GL errors and fatal-error messages.

## Building from source

Needs the VitaSDK toolchain plus these VitaSDK packages: SDL2, SDL2_image, vitaGL (+vitashark,
SceShaccCgExt, libmathneon), openal-soft, libvorbis, libtheora, libogg, libpng, libjpeg-turbo,
libwebp, zlib, zstd, bzip2, taihen, and **curl-mbedtls** (the OpenSSL-flavoured `curl` package
does not link against the mbedtls libraries used here).

```sh
export VITASDK=/path/to/vitasdk
make -f vita/Makefile            # from the repository root -> build-vita/KeeperRL.vpk
```

The LiveArea/icon images are in `vita/sce_sys/` (`icon0.png`, `pic0.png`, `livearea/contents/*`) and
are packed into the VPK as-is. They are binary files, so `keeperrl-vita.patch` does not carry them:
if you build from the patch, copy your `sce_sys` folder to `vita/sce_sys` first (the source zip
already includes it).

A full build compiles ~240 C++ files and takes a long time on a single core (about an hour).

## How the port works (for developers)

* `vita/vita_platform.cpp` -- entry point (runs the game on a 16 MB-stack thread), memory and
  thread-stack settings, vitaGL init, error dialog, gamepad -> mouse/keyboard event emulation.
* Threading: libstdc++ only considers threads "active" if the weak symbol `pthread_cancel` gets
  linked in, which never happens in a static Vita link (`std::thread` then throws "Enable
  multithreading to use std::thread", and `std::mutex` silently does nothing). `vita_platform.cpp`
  holds a strong reference to it to force it in. Do not remove it.
* The game is always started with `--stderr`, so its INFO messages go to `log.txt` (line-buffered,
  so a crash keeps the last lines). The log also has memory-usage lines (`[mem] ...`) and renderer
  startup steps. Remove `--stderr` in `main()` of `vita_platform.cpp` once the port is stable.
* `sdl.h` -- on Vita, includes vitaGL instead of desktop `SDL_opengl.h` and re-exports the GL API
  into `namespace SDL`, so the existing `SDL::glFoo()` call sites are unchanged
  (`vita/gen_gl_using.py` generates the list; `vita/vita_gl.h` has typedefs and small shims).
* `renderer.cpp` -- Vita branches for window/GL setup, buffer swap, event polling, and a software
  mouse cursor.
* vitaGL quirks handled: `glPixelStorei` (only supports `GL_UNPACK_ROW_LENGTH`), `glGetError`
  (logged instead of fatal), missing `glDrawBuffers` / `glDebugMessage*`.
* `vita/steam_stubs.cpp` -- no-op `MySteamInput` / `SteamAchievements`. `main.cpp` always
  constructs a `MySteamInput` (backed by these stubs), even without Steamworks: many places in the UI
  code (`GuiFactory::scripted()`, used by the main menu, and others) call `getSteamInput()->...`
  unconditionally with no null check. Upstream only constructed it under `USE_STEAMWORKS`, which
  crashed the port on the very first screen with a null-pointer dereference. Do not revert this to
  the old `#ifdef USE_STEAMWORKS`-only construction.
* The paid `data` folder is read from `ux0:data/KeeperRL/data`, not from the app0: install (see
  "Paid data", below).
* `file_sharing.cpp` -- `curl_easy_init()` returns null on Vita so online features fail gracefully.
* Other small fixes: `sincosf` (missing in newlib), `openUrl`, `main.cpp` (non-Steam builds
  never included `translations.h`, and dereferenced a null `steamInput`).

## Memory

The Vita gives an app a fixed amount of user RAM, shared by: the game heap, thread stacks, vitaGL's
RAM pool, the executable, audio and the system. vitaGL keeps textures in the separate 128 MB of video
memory ("cdram"), which it claims entirely.

**Enlarged memory (`ATTRIBUTE2`).** The port's `param.sfo` contains `ATTRIBUTE2 = 12` (0x0C), which is
the default `vita-mksfoex` writes. According to the PlayStation Dev Wiki (Vita, PARAM.SFO), the bits of
`ATTRIBUTE2` mean: 0x04 = enlarged memory (+29 MiB), 0x08 = +77 MiB, 0x0C = +109 MiB. A Julius Vita
port developer notes in code that the maximum newlib heap is 330 MB with `-d ATTRIBUTE2=12` and 192 MB
without it. Those figures do not line up exactly (192 + 109 = 301), so treat 330 MB as a rough upper
bound, not a guarantee. This port has not measured it on hardware yet: the `[mem] process start` line in
the log shows what is really free.

* **The game checks this itself at startup.** It reads the installed `param.sfo` and writes one line to
  `log.txt`, e.g. `[sfo] TITLE_ID=KRLVT0001: ATTRIBUTE2=0x0000000C (enlarged memory +109 MiB) - as
  intended`, or a `WARNING` line if the flag is missing or reduced. This only inspects the file; the
  `[mem]` lines show how much memory the system really granted.
* **Keep `ATTRIBUTE2=12` in whatever `param.sfo` you install with.** If you swap in an SFO borrowed
  from another homebrew that lacks it, the app may get much less memory and run out early.
* Sony's documentation for the official expansion modes (Unity) says that when enabled, other
  applications are terminated at launch and cannot be run while the app is running. Whether that applies
  unchanged to homebrew with this flag is unverified.

Settings at the top of `vita/vita_platform.cpp`:

* `VITA_HEAP_MB` -- the game's malloc heap, reserved at startup (160).
* `VITA_THREAD_STACK_SMALL_KB` -- default stack of every `std::thread` (1 MB). `makeThread()` (used for
  content loading and world generation) temporarily raises it to `VITA_BIG_THREAD_STACK` (8 MB).
* `VITA_MAIN_STACK_MB` -- stack of the thread the whole game runs on (8).
* `VGL_LEGACY_POOL_BYTES` (8 MB, for `glBegin`/client vertex arrays) + `VGL_RAM_POOL_EXTRA` (16 MB) --
  the RAM pool vitaGL gets. vitaGL takes *all free RAM minus a threshold*, so the threshold is computed
  at startup to leave everything else free.

An earlier version let vitaGL take everything except 16 MB and gave every thread an 8 MB stack, which
exhausted RAM within seconds of startup (`sys free: user 0 MB`).

Note: `vglInitExtended` / `vglInitWithCustomThreshold` do **not** return a success flag; the value is
`GL_TRUE` only if the requested resolution had to be reduced. The port ignores it.

## Reading the log (`ux0:data/KeeperRL/log.txt`)

While the game runs, a background thread writes a `[perf]` line every 5 seconds:

```
[perf] fps=17.1 avg=58.4ms worst=266ms (88 frames/5.1s) | heap 87.3/192 MB (peak 91.0) | sys free: user 41 MB, cdram 88 MB, phycont 3 MB | vgl free: vram 71/128 MB, ram 9/16 MB, phycont 2/8 MB
```

* `fps` / `avg` / `worst` -- frames presented in the last interval, their average time, and the single
  slowest frame (a long "worst" with a fine "avg" means hitches, e.g. from garbage or loading).
* `NO FRAMES in the last 5.0s` -- nothing was drawn: loading, world generation, or a hang.
* `heap X/192 MB (peak Y)` -- the game's own memory (newlib heap; `VITA_HEAP_MB` in `vita_platform.cpp`).
* `sys free` -- what the whole system still has free (user RAM, CDRAM = video memory, physically
  contiguous RAM). `vgl free` -- vitaGL's own pools (`free/total`).
* `!! HEAP NEARLY FULL` (>90% of the heap) and `!! SYSTEM RAM LOW` (<8 MB free) mark trouble.

`[sfo] ...` is the startup `ATTRIBUTE2` check (see Memory). `[mem] <step>: ...` lines give the same memory numbers at startup milestones, and a
`[perf] first frame presented ...` line gives the time to the first drawn frame. Everything else in
the log is the game's own INFO output (the game is started with `--stderr`).

## Tests

`VITASDK=/path/to/vitasdk sh vita/tests/run_tests.sh` builds and runs, on your PC, tests of the
gamepad -> mouse/keyboard mapping, the fps/memory monitor and the `param.sfo` reader (the latter under
AddressSanitizer/UBSan, including thousands of malformed inputs). They run the real
`vita_platform.cpp` against a fake pad, clock and memory numbers; no Vita needed.

## Parsing a crash dump (`psp2core-*.psp2dmp`)

If VitaShell shows a "coredump saved" notice (or one appears in `ux0:data/`), it is a full ELF crash
dump: which thread crashed, its registers, a disassembly around the crash address, and the stack.
`vita/tools/` holds a Python 3 port of xyzz/vita-parse-core (the original is Python 2, which modern
systems don't have):

```sh
pip install pyelftools
export PATH=$VITASDK/bin:$PATH   # needs arm-vita-eabi-objdump and arm-vita-eabi-addr2line
python3 vita/tools/main.py path/to/psp2core-....psp2dmp build-vita/KeeperRL.elf
```

Use the exact `KeeperRL.elf` from the build that produced the dump (kept in `build-vita/` after a
build; addresses won't line up with a different build). The build's `-g0` means no source line
numbers, but function names still resolve since the binary isn't stripped.

## Diagnosing the post-loading hang (current known issue)

The last real-hardware run got much further than before (fixed main-menu crash confirmed working,
all paid tiles loaded, real audio/tiles found under `ux0:data/KeeperRL/data`), but then hung
completely after tileset loading: no crash, no further log lines, memory numbers frozen, for
several minutes. The likely area is one of several things that happen right after tileset loading
finishes and before the game loop starts: constructing `FileSharing` (spawns a background
upload-queue thread), `WindowView::createDefaultView`, `view->initialize`, or constructing
`Jukebox` (spawns a background music-refresh thread) -- any of these could be where it's actually
stuck, and the log alone doesn't say which.

`main.cpp` now logs a `checkpoint: ...` line (to `log.txt`) before and after each of these steps.
The next hang will show exactly which checkpoint was last reached, which tells us precisely which
step never returns.

## If it crashes

Send `ux0:data/KeeperRL/log.txt` (and a description of when it happened). The log records the
startup sequence, GL errors and fatal-error messages.
