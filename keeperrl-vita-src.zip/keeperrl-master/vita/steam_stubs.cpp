// No-op replacements for the Steamworks-dependent parts of the game (steam_input.cpp and
// steam_achievements.cpp need the proprietary Steamworks SDK, which is not part of this repo).
#include "steam_input.h"
#include "steam_achievements.h"
#include "achievement_id.h"

void MySteamInput::init() {}
void MySteamInput::showBindingScreen() {}
void MySteamInput::showFloatingKeyboard(Rectangle) {}
void MySteamInput::dismissFloatingKeyboard() {}
optional<ControllerKey> MySteamInput::getEvent() { return none; }
void MySteamInput::setGameActionLayer(GameActionLayer) {}
pair<double, double> MySteamInput::getJoyPos(ControllerJoy) { return {0, 0}; }
void MySteamInput::runFrame() {}
bool MySteamInput::isPressed(ControllerKey) { return false; }
bool MySteamInput::isRunningOnDeck() { return false; }
optional<FilePath> MySteamInput::getGlyph(ControllerKey) { return none; }
void MySteamInput::detectControllers() {}

SteamAchievements::SteamAchievements() {}
void SteamAchievements::achieve(AchievementId) {}
