import struct


def u16(buf, off):
    return struct.unpack("<H", bytes(buf[off:off + 2]))[0]


def u32(buf, off):
    return struct.unpack("<I", bytes(buf[off:off + 4]))[0]


def c_str(buf, off):
    end = off
    while end < len(buf) and buf[end] != 0:
        end += 1
    return bytes(buf[off:end]).decode("latin1")


def hexdump(src, length=16, sep='.'):
    lines = []
    for c in range(0, len(src), length):
        chars = src[c:c + length]
        hexs = ' '.join(["%02x" % b for b in chars])
        if len(hexs) > 24:
            hexs = "%s %s" % (hexs[:24], hexs[24:])
        printable = ''.join([chr(b) if 32 <= b < 127 else '.' for b in chars])
        lines.append("%08x:  %-*s  |%s|\n" % (c, length * 3, hexs, printable))
    print(''.join(lines))
