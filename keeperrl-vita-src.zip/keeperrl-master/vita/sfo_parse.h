// Minimal, defensive reader for PS Vita param.sfo files (PSF format), used to check at startup whether
// the installed param.sfo really carries the "enlarged memory" flag (ATTRIBUTE2).
//
// The input can be any file that ended up installed (e.g. an SFO swapped in from another homebrew), so
// every offset and length is bounds-checked and malformed input can never read outside the buffer.
// No SDK dependencies: it is unit-tested on a PC (vita/tests/test_sfo.cpp, also under ASan/UBSan).
#pragma once
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

namespace vitasfo {

const uint16_t FMT_UTF8_SPECIAL = 0x0004;
const uint16_t FMT_UTF8 = 0x0204;    // NUL-terminated string
const uint16_t FMT_UINT32 = 0x0404;  // 32-bit little-endian integer

inline uint16_t rd16(const uint8_t* p) { return (uint16_t)(p[0] | (p[1] << 8)); }
inline uint32_t rd32(const uint8_t* p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

// Locates `key`. On success sets the value's format, and its offset and length inside `d`.
inline bool find(const uint8_t* d, size_t len, const char* key, uint16_t* fmt, size_t* off, size_t* vlen) {
  if (!d || len < 20)
    return false;
  if (!(d[0] == 0 && d[1] == 'P' && d[2] == 'S' && d[3] == 'F'))
    return false;
  uint64_t keyTable = rd32(d + 8), dataTable = rd32(d + 12), count = rd32(d + 16);
  if (count > 4096 || 20 + count * 16 > len || keyTable > len || dataTable > len)
    return false;
  size_t keyLen = strlen(key);
  for (uint64_t i = 0; i < count; ++i) {
    const uint8_t* e = d + 20 + i * 16;
    uint64_t keyPos = keyTable + rd16(e);
    if (keyPos >= len)
      continue;
    const uint8_t* nul = (const uint8_t*)memchr(d + keyPos, 0, len - (size_t)keyPos);
    if (!nul || (size_t)(nul - (d + keyPos)) != keyLen || memcmp(d + keyPos, key, keyLen) != 0)
      continue;
    uint64_t valueLen = rd32(e + 4), valuePos = dataTable + rd32(e + 12);
    if (valuePos > len || valueLen > len - valuePos)
      return false;
    *fmt = rd16(e + 2);
    *off = (size_t)valuePos;
    *vlen = (size_t)valueLen;
    return true;
  }
  return false;
}

inline bool getUint32(const uint8_t* d, size_t len, const char* key, uint32_t* out) {
  uint16_t fmt;
  size_t off, vlen;
  if (!find(d, len, key, &fmt, &off, &vlen) || fmt != FMT_UINT32 || vlen != 4)
    return false;
  *out = rd32(d + off);
  return true;
}

inline bool getString(const uint8_t* d, size_t len, const char* key, char* out, size_t outSize) {
  uint16_t fmt;
  size_t off, vlen;
  if (outSize == 0 || !find(d, len, key, &fmt, &off, &vlen) || (fmt != FMT_UTF8 && fmt != FMT_UTF8_SPECIAL))
    return false;
  size_t n = 0;
  while (n < vlen && n + 1 < outSize && d[off + n] != 0) {
    out[n] = (char)d[off + n];
    ++n;
  }
  out[n] = 0;
  return true;
}

// ATTRIBUTE2 memory bits (PlayStation Dev Wiki, Vita PARAM.SFO): 0x04 = enlarged memory (+29 MiB),
// 0x08 = +77 MiB, 0x0C = +109 MiB. vita-mksfoex writes 12 (0x0C) by default.
inline const char* enlargedMemoryText(uint32_t attribute2) {
  switch (attribute2 & 0x0C) {
    case 0x0C: return "enlarged memory +109 MiB";
    case 0x08: return "enlarged memory +77 MiB";
    case 0x04: return "enlarged memory +29 MiB";
    default: return "no enlarged memory";
  }
}

// Writes a one-line report about the installed SFO into `out`.
// Returns 0 = as intended (ATTRIBUTE2 has the +109 MiB bits), 1 = warning (flag missing/reduced),
// 2 = the file could not be understood as an SFO at all.
inline int describeAttribute2(const uint8_t* d, size_t len, char* out, size_t outSize) {
  uint16_t fmt;
  size_t off, vlen;
  if (!find(d, len, "TITLE_ID", &fmt, &off, &vlen) && !find(d, len, "ATTRIBUTE2", &fmt, &off, &vlen)) {
    snprintf(out, outSize, "[sfo] param.sfo is not a readable SFO (%u bytes): cannot verify ATTRIBUTE2",
             (unsigned)len);
    return 2;
  }
  char title[32] = "?";
  getString(d, len, "TITLE_ID", title, sizeof(title));
  uint32_t attr2 = 0;
  if (!getUint32(d, len, "ATTRIBUTE2", &attr2)) {
    snprintf(out, outSize,
             "[sfo] TITLE_ID=%s: ATTRIBUTE2 is MISSING -> no enlarged memory. WARNING: expect much less RAM "
             "than intended; install with the param.sfo from the VPK (or one built with -d ATTRIBUTE2=12)",
             title);
    return 1;
  }
  if ((attr2 & 0x0C) != 0x0C) {
    snprintf(out, outSize,
             "[sfo] TITLE_ID=%s: ATTRIBUTE2=0x%08X (%s). WARNING: not 12 (0x0C = +109 MiB); expect less RAM "
             "than intended",
             title, (unsigned)attr2, enlargedMemoryText(attr2));
    return 1;
  }
  snprintf(out, outSize, "[sfo] TITLE_ID=%s: ATTRIBUTE2=0x%08X (%s) - as intended", title, (unsigned)attr2,
           enlargedMemoryText(attr2));
  return 0;
}

}  // namespace vitasfo
